package com.capgemini.bankcustomer.exception;

public class BankCustomerNotFound extends Exception{
	
	public BankCustomerNotFound(String message) 
	{
		super(message);
		}

}

