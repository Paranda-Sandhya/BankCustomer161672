package com.capgemini.bankcustomer.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="BankDetails")
public class BankCustomer {
	 @Id
	 // @GeneratedValue(strategy=GenerationType.IDENTITY)
	  int accountNumber;
	  
	  @NotNull
 private String name;
 private String mobNumber;
 private String aadhaarNumber;
 private String address ;
private double currentBalance=0;
public BankCustomer(){
}


public BankCustomer(int accountNumber, String name, String mobNumber,
		String aadhaarNumber, String address, double currentBalance) {
	super();
	this.accountNumber = accountNumber;
	this.name = name;
	this.mobNumber = mobNumber;
	this.aadhaarNumber = aadhaarNumber;
	this.address = address;
	this.currentBalance = currentBalance;
}

public int getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(int accountNumber) {
	this.accountNumber = accountNumber;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getMobNumber() {
	return mobNumber;
}
public void setMobNumber(String mobNumber) {
	this.mobNumber = mobNumber;
}
public String getAadhaarNumber() {
	return aadhaarNumber;
}
public void setAadhaarNumber(String aadhaarNumber) {
	this.aadhaarNumber = aadhaarNumber;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public double getCurrentBalance() {
	return currentBalance;
}
public void setCurrentBalance(double currentBalance) {
	this.currentBalance = currentBalance;
}

 
}
      