package com.capgemini.bankcustomer.dto;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Banktransactions")

public class PrintTransaction {

	@Id
	private int accountNumber;
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int transId;
	private String transType;
	private double balance;
	private LocalDate transDate;
	//private int accountNumber;
	
	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public PrintTransaction() {
		
	}

	public PrintTransaction(int transId,
			double balance, LocalDate transDate) {
		super();
		this.transId = transId;
		
		this.transType = transType;
		this.balance = balance;
		this.transDate = transDate;
	}

	public int getTransId() {
		return transId;
	}

	public void setTransId(int transId) {
		this.transId = transId;
	}



	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	@Override
	public String toString() {
		return "PrintTransaction [transId=" + transId + ", transType="
				+ transType + ", balance=" + balance + ", transDate="
				+ transDate + ", accountNumber=" + accountNumber + "]";
	}

	
	
	

}
