package com.capgemini.bankcustomer.dto;

import java.time.LocalDate;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Banktransactions")

public class PrintTransaction {

	@Id
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transId;
	//private String transType;
	private double balance;
	private LocalDate transDate;
	
	public PrintTransaction() {
		
	}

	public PrintTransaction(Integer transId,
			double balance, LocalDate transDate) {
		super();
		this.transId = transId;
		
		//this.transType = transType;
		this.balance = balance;
		this.transDate = transDate;
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}



	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public LocalDate getTransDate() {
		return transDate;
	}

	@Override
	public String toString() {
		return "PrintTransaction [transId=" + transId + ", balance=" + balance
				+ ", transDate=" + transDate + "]";
	}

	public void setTransDate(LocalDate transDate) {
		this.transDate = transDate;
	}

	
	
	

}
