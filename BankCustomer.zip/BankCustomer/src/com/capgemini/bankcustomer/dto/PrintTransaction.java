package com.capgemini.bankcustomer.dto;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name = "Banktransactions")

public class PrintTransaction {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transId;
	private String transType;
	private double balance;
	public String getTransDetails() {
		return transDetails;
	}

	public void setTransDetails(String transDetails) {
		this.transDetails = transDetails;
	}

	private Date transDate;
	private String transDetails;
	
	public PrintTransaction() {
		
	}

	public PrintTransaction(Integer transId,
			String transType, double balance, Date transDate) {
		super();
		this.transId = transId;
		
		this.transType = transType;
		this.balance = balance;
		this.transDate = transDate;
		this.transDetails=transDetails;
	}

	public Integer getTransId() {
		return transId;
	}

	public void setTransId(Integer transId) {
		this.transId = transId;
	}


	public String getTransType() {
		return transType;
	}

	public void setTransType(String transType) {
		this.transType = transType;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Date getTransDate() {
		return transDate;
	}

	public void setTransDate(Date transDate) {
		this.transDate = transDate;
	}

	@Override
	public String toString() {
		return "PrintTransaction [transId=" + transId + ", transType=" + transType + ", balance=" + balance
				+ ", transDate=" + transDate + ", transDetails=" + transDetails + "]";
	}

	

	
	
	

}
