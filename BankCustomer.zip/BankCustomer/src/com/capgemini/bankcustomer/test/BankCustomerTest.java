package com.capgemini.bankcustomer.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.bankcustomer.dao.BankCustomerDAOimpl;

public class BankCustomerTest extends BankCustomerDAOimpl {

	@Test
	public void testCreateAccount() {
		fail("Not yet implemented");
	}

	@Test
	public void testShowBalance() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		fail("Not yet implemented");
	}

	@Test
	public void testWithdraw() {
		fail("Not yet implemented");
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testPrintTransaction() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidAccountNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidateAmount() {
		fail("Not yet implemented");
	}

}
