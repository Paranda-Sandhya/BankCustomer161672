package com.capgemini.bankcustomer.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.bankcustomer.dao.BankCustomerDAOimpl;
import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.service.BankCustomerServiceImpl;

public class BankCustomerTest extends BankCustomerDAOimpl {
	//BankCustomer a = new BankCustomer(null,9951942754,7894561230,"Pune",0.0);
	BankCustomerDAOimpl d = new BankCustomerDAOimpl();
	//BankCustomerServiceImpl b=new BankCustomerServiceImpl();
	//BankCustomer c=null;
	BankCustomer a = new BankCustomer(0,"Sandy","9874563210","9638527410","Mumbai", 0.0);
	
	@Test
	public void testCreateAccount() {
/*		
c=new BankCustomer();
c.setName("Sandhya");
c.setMobNumber("9502929510");
c.setAadhaarNumber("9876352410");
c.setAddress("Hyderabad");
c.setCurrentBalance(0);
boolean e;*/
//try{
	//e=d.createAccount(c);
	//assertTrue("true",e);
	//catch(CustomerNotFoundException e){
		//e.printStackTrace();
	//}

	}

	@Test
	public void testShowBalance() {
		//fail("Not yet implemented");
	}

	@Test
	public void testDeposit() {
		
	}

	@Test
	public void testWithdraw() {
	
	}

	@Test
	public void testFundTransfer() {
		fail("Not yet implemented");
	}

	@Test
	public void testValidAccountNumber() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddTransaction() {
		fail("Not yet implemented");
	}

}
