package com.capgemini.bankcustomer.service;



import java.util.List;

import javax.transaction.Transaction;

import com.capgemini.bankcustomer.dao.BankCustomerDAOimpl;
import com.capgemini.bankcustomer.dao.IBankCustomerDAO;
import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.dto.PrintTransaction;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;




public class BankCustomerServiceImpl implements IBankCustomerDAO {
	        BankCustomerDAOimpl d=new BankCustomerDAOimpl();
	    
	    @Override
	    public void createAccount(BankCustomer b) throws BankCustomerNotFound {
	        // TODO Auto-generated method stub
	        
	        d.createAccount(b);
	        
	    }
	    
	    
	    
	    @Override
	    public BankCustomer showBalance(int accountNumber)throws BankCustomerNotFound {
	   return d.showBalance(accountNumber);
	        }
	    
	    
	    
	    @Override
	    public double deposit(int accountNumber,double deposit,PrintTransaction transaction) throws BankCustomerNotFound{
	    	return d.deposit(accountNumber,deposit,transaction);
			}
			
	    
	    

	    @Override
	   
	    public double withdraw(int accountNumber, double withdraw, PrintTransaction transaction ) throws BankCustomerNotFound{
	
	    		
	    			
	    		return d.withdraw(accountNumber,withdraw, transaction);
	    	}
	    @Override
	    public PrintTransaction fundTransfer(int senderAcc ,int receiverAcc, double fund, PrintTransaction transaction) throws BankCustomerNotFound{
	    	
	  
	        return d.fundTransfer(senderAcc ,receiverAcc ,fund, transaction);

	    }
	    
	    
	    
	    
	    
	    @Override
	    public List<PrintTransaction> printTransaction(long accountNo) throws BankCustomerNotFound{
	        // TODO Auto-generated method stub
	        return d.printTransaction(accountNo);
	        

	    }
	    
	    
	    
	    public  boolean addBean(BankCustomer b)throws BankCustomerNotFound {
	        boolean flag=false;
	        if(isValidName(b.getName()) && isValidMobNumber(b.getMobNumber()) && isValidAddress(b.getAddress()) && isValidaadharNumber(b.getAadhaarNumber()));
	        flag=true;
	        
	        return flag;
	        
	    }
	    public boolean isValidName(String name) throws BankCustomerNotFound{
	        boolean flag=false;
	        if(((name!=null) && name.matches("[A-Z][a-z]+"))) {
	            flag= true;
	        }else {
	            System.err.println("Invalid Name Please enter in the format eg:Anusree");
	            flag=false;
	        }
	        return flag;
	        
	    }
	    public boolean isValidMobNumber(String mobNumber)throws BankCustomerNotFound {
	        boolean flag=false;
	        if(((mobNumber !=null) && mobNumber.matches("[4-9][0-9]{9}"))){
	            flag=true;
	        }else {
	            System.err.println("Invalid MobileNumber");
	        flag=false;
	        }return flag;
	        
	            
	        }
	    public boolean isValidAddress(String address )throws BankCustomerNotFound {
	        boolean flag=false;
	        if(((address!=null) && address.matches("[A-Z][a-z]+"))) {
	            flag= true;
	        }else {
	            System.err.println("Invalid Address please enter using given format eg:Hyderabad");
	            flag=false;
	        }return flag;
	    }
	    
	        public boolean isValidaadharNumber(String aadharNumber)throws BankCustomerNotFound {
	            boolean flag=false;
	            if(((aadharNumber !=null) && aadharNumber.matches("[1-9][0-9]{9}"))) {
	                flag=true;
	            }else
	                System.err.println("Invalid AadharNumber.The aadharnumber should be 10 digits");
	            
	            return flag;
	        }
	        

	    

	    
	   
	    public boolean validAccountNumber(int accountNumber5)throws BankCustomerNotFound
	    {
	    return  d.validAccountNumber(accountNumber5);
	        // TODO Auto-generated method stub
	    }
	    
	    
	    public boolean validateAmount(double withdraw)throws BankCustomerNotFound
		{
			return d.validateAmount(withdraw);
		}



		@Override
		public PrintTransaction addTransaction(PrintTransaction transaction)
				throws BankCustomerNotFound {
			// TODO Auto-generated method stub
			return null;
		}



		
	    }