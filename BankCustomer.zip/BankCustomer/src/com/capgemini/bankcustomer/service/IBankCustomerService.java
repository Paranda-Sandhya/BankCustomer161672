package com.capgemini.bankcustomer.service;

import org.springframework.context.annotation.Bean;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;


public interface IBankCustomerService {


    public double showBalance(int accountNumber)throws BankCustomerNotFound ;

    public void createAccount(Bean b) throws BankCustomerNotFound;

    public double deposit(double deposit,int accountNumber) throws BankCustomerNotFound;

    public double withdraw(int accountNumber, double withdraw) throws BankCustomerNotFound;

    public double fundTransfer(int accountNumber4, int accountNumber5, int amount)
			throws BankCustomerNotFound;
    public void printTransaction()throws BankCustomerNotFound;


    public boolean validAccountNumber(int accountNumber5) throws BankCustomerNotFound;

    public boolean validateAmount(double withdraw)throws BankCustomerNotFound;
    
}
