package com.capgemini.bankcustomer.service;

import java.util.List;

import javax.transaction.Transaction;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.dto.PrintTransaction;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;

public interface IBankCustomerService {

	public BankCustomer showBalance(int accountNumber)
			throws BankCustomerNotFound;

	public void createAccount(BankCustomer b) throws BankCustomerNotFound;

	public double deposit(int accountNumber, double deposit,PrintTransaction transaction)
			throws BankCustomerNotFound;

	public double withdraw(int accountNumber, double withdraw, PrintTransaction transaction)
			throws BankCustomerNotFound;

	public PrintTransaction fundTransfer(int senderAcc, int receiverAcc, double fund, PrintTransaction transaction)
			throws BankCustomerNotFound;

	public List<PrintTransaction> printTransaction(long accountNo) throws BankCustomerNotFound;

	public Transaction addTransaction(PrintTransaction transaction)
			throws BankCustomerNotFound;


	public boolean validateAmount(double withdraw) throws BankCustomerNotFound;

}
