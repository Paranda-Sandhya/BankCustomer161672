package com.capgemini.bankcustomer.ui;


import java.util.List;
import java.util.Scanner;

import com.capgemini.bankcustomer.dao.BankCustomerDAOimpl;
import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;
import com.capgemini.bankcustomer.service.BankCustomerServiceImpl;
import com.wallet.dto.PrintTransactions;
import com.wallet.exception.BankException;
import com.wallet.exception.InvalidPhoneNumber;


public class MainMenu {
	
	
public static void main(String[]args) throws BankCustomerNotFound
	    {       
         BankCustomerServiceImpl service=new BankCustomerServiceImpl();
	     BankCustomer b=new BankCustomer();
	         
	        String name;
	        String mobNumber;
	        String aadhaarNumber;
	      
	        String address;
	        boolean m;

	        Scanner sc =new Scanner(System.in);
	        
	        while(true) {
            System.out.println("Welcome to UBI Bank");
	       System.out.println(" 1.Create account");
	        System.out.println("2.ShowBalance");
	        System.out.println("3.Deposit");
	        System.out.println("4.Withdraw");
	        System.out.println("5.FundTransfer");
	        System.out.println("6.Print Transactions");
	        System.out.println("7.Exit");
	       int   ch=sc.nextInt();
	        
	        switch(ch){
	        
	            case 1 :
	            
	            do {
	                        
	                    System.out.println("Enter your Name");
	                    name=sc.next();
	                    m=service.isValidName(name);
	                    }while(m==false);
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter your Aadhar number");
	                    aadhaarNumber=sc.next();
	                    m=service.isValidaadharNumber(aadhaarNumber);
	                    }while(m==false);
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter the MobNumber");
	                    mobNumber=sc.next();
	                    m=service.isValidMobNumber(mobNumber);
	                    }while(m==false) ;
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter your address");
	                     address=sc.next();
	                    m=service.isValidAddress(address);
	                    }while(m==false);
	                    
	                    
	                    
	                    b.setName(name);
	                    b.setAadhaarNumber(aadhaarNumber);
	                    b.setMobNumber(mobNumber);
	                    b.setAddress(address);
	              
	                  
	                    int  accountNumber =(int)((Math.random()*100)+1000);
	                   
	                    b.setAccountNumber(accountNumber);
	                    boolean isValid=service.addBean(b);
	                    if(isValid) {
	                        service.createAccount(b);
	                        System.out.println(b);
	                        System.out.println("Account created successfully");
	                        
	                    }else {
	                        System.out.println("Not Recorded");
	                    }
	                    
	                    System.out.println(b.getAccountNumber());
	                    
	                    
	                    break;
	            case 2 :System.out.println("show balance");
	                    System.out.println("enter the account number");
	                    int accountNumber1 = sc.nextInt();
	                   
	                  BankCustomer s= service.showBalance(accountNumber1);
	                  System.out.println("Availaible balance in " + s.getAccountNumber() + " is Rs." + s.getCurrentBalance());
	            
	            case 3:
	                System.out.println("deposit");
	                System.out.println("enter the account number");
	                int accountNumber2 = sc.nextInt();
	                
	                
	                boolean valid1 = service.validAccountNumber( accountNumber2);
	                if (valid1) {
	                    System.out.println("enter the amount to be deposit");
	                    double deposit = sc.nextDouble();
	                    double dep = service.deposit(accountNumber2,deposit);
	                    b.setCurrentBalance(dep);
	                    System.out.println("deposited successfully");
	                    System.out.println("the deposited amount is" + dep);
	                    System.out.println("Balance is" + dep);


	                } else
	                    System.out.println("Enter the valid amount");

	                break;
	                        
	            case 4:     
	                    System.out.println(" withdraw ");
	                    System.out.println("enter the account number");                                            
	                    int accountNumber3 = sc.nextInt();                                                              
	                                                                                       
	                    boolean valid2= service.validAccountNumber( accountNumber3);                             
	                    if (valid2) {                                                                               
	                    	System.out.println("enter the amount to be withdraw");                                 
	                    	double withdraw = sc.nextInt();   
	                    	double withdraw1=service.withdraw(accountNumber3, withdraw);
	                    	b.setCurrentBalance(withdraw1);
	                    	                      
	                    		System.out.println("withdraw successful");                                         
	                    		System.out.println("withdrawn amount is"+withdraw1);                                
	                    		System.out.println(" Remaining balance is :" + withdraw1);                    
	                    	} else                                                                                 
	                    		System.out.println("the amount should not be more than available amount");         
	                                                          
	                                                                                                               
	                    break;                                                                                     
	                                                                                                               
	                  
	            case 5:
	            	System.out.println("Enter the Debiter's  Account Number");
					int id4=sc.nextInt();
					System.out.println("Enter Receiver's Account Number");
					int id5=sc.nextInt();
					System.out.println("Enter the amount to be transfered");
					double fund=sc.nextDouble();
					System.out.println(service.fundTransfer(id4,id5,fund));
					
	            		
		      case 6:
		    	  System.out
					.println("Enter Accountnumber to print transactions:");
			String mob = sc.next();
			List<PrintTransactions> list = null;

			try {
				if (service.validaccountNumber(accountNumber))
					list = service.getTransactions(accountnumber);
				for (PrintTransactions pt : list)
					System.out.println(pt);
			} catch (BankCustomerNotFound e) {
				System.err.println(e.getMessage());
			}

			break;;
	            case 7: 
	            	System.out.println( "Thankyou for using UBI  Bank");
	            	System.exit(0);
	            default: 
	                    System.out.println("wrong choice /n Please enter correct choice");
	                    break;
	        }
	        
	            }
	        }
}