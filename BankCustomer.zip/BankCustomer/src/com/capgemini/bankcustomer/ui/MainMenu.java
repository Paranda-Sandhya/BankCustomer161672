package com.capgemini.bankcustomer.ui;


import java.util.Scanner;

import com.capgemini.bankcustomer.dao.BankCustomerDAOimpl;
import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;
import com.capgemini.bankcustomer.service.BankCustomerServiceImpl;


public class MainMenu {
	
	 static BankCustomerServiceImpl service=new BankCustomerServiceImpl();
	    static BankCustomer b=new BankCustomer();
	    //BankCustomerDAOimpl dao=new BankCustomerDAOimpl();
	    
	    
	    
	    public static void main(String[]args) throws BankCustomerNotFound
	    {       
	        
	        
	        String name;
	        String mobNumber;
	        String aadhaarNumber;
	      
	        String address;
	        boolean m;

	        Scanner sc =new Scanner(System.in);
	        
	        while(true) {

	        System.out.println(" 1.Create account");
	        System.out.println("2.ShowBalance");
	        System.out.println("3.Deposit");
	        System.out.println("4.Withdraw");
	        System.out.println("5.FundTransfer");
	        System.out.println("6.Print Transactions");
	        
	       int   ch=sc.nextInt();
	        
	        switch(ch){
	        
	            case 1 :
	            
	            do {
	                        
	                    System.out.println("Enter your Name");
	                    name=sc.next();
	                    m=service.isValidName(name);
	                    }while(m==false);
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter your Aadhar number");
	                    aadhaarNumber=sc.next();
	                    m=service.isValidaadharNumber(aadhaarNumber);
	                    }while(m==false);
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter the MobNumber");
	                    mobNumber=sc.next();
	                    m=service.isValidMobNumber(mobNumber);
	                    }while(m==false) ;
	                    
	                    
	                    do {
	                        
	                    System.out.println("Enter your address");
	                     address=sc.next();
	                    m=service.isValidAddress(address);
	                    }while(m==false);
	                    
	                    
	                    
	                    b.setName(name);
	                    b.setAadhaarNumber(aadhaarNumber);
	                    b.setMobNumber(mobNumber);
	                    b.setAddress(address);
	              
	                  
	                    int  accountNumber =(int)((Math.random()*100)+1000);
	                   
	                    b.setAccountNumber(accountNumber);
	                    boolean isValid=service.addBean(b);
	                    if(isValid) {
	                        service.createAccount(b);
	                        System.out.println(b);
	                        System.out.println("Account created successfully");
	                        
	                    }else {
	                        System.out.println("Not Recorded");
	                    }
	                    
	                    System.out.println(b.getAccountNumber());
	                    
	                    
	                    break;
	            case 2 :System.out.println("show balance");
	                    System.out.println("enter the account number");
	                    int accountNumber1 = sc.nextInt();
	                   
	            
	                    boolean valid= service.validAccountNumber( accountNumber1);
	                    if (valid) {
	                    	
	                     double balanceAmount = service.showBalance(accountNumber1);
	                        System.out.println("Balance is" + balanceAmount);
	                    }else
	                        System.out.println("enter valid details");
	                        
	                        break;
	            
	            case 3:
	                System.out.println("deposit");
	                System.out.println("enter the account number");
	                int accountNumber2 = sc.nextInt();
	                
	                
	                boolean valid1 = service.validAccountNumber( accountNumber2);
	                if (valid1) {
	                    System.out.println("enter the amount to be deposit");
	                    double deposit = sc.nextDouble();
	                    double deposit1 = service.deposit(deposit,accountNumber2);
	                    b.setCurrentBalance(deposit1);
	                    System.out.println("deposited successfully");
	                    System.out.println("the deposited amount is" + deposit1);
	                    System.out.println("Balance is" + deposit1);


	                } else
	                    System.out.println("Enter the valid amount");

	                break;
	                        
	            case 4:     
	                    System.out.println(" withdraw ");
	                    System.out.println("enter the account number");                                            
	                    int accountNumber3 = sc.nextInt();                                                              
	                                                                                       
	                    boolean valid2= service.validAccountNumber( accountNumber3);                             
	                    if (valid2) {                                                                               
	                    	System.out.println("enter the amount to be withdraw");                                 
	                    	double withdraw = sc.nextInt();   
	                    	double withdraw1=service.withdraw(accountNumber3, withdraw);
	                    	b.setCurrentBalance(withdraw1);
	                    	                      
	                    		System.out.println("withdraw successful");                                         
	                    		System.out.println("withdrawn amount is"+withdraw1);                                
	                    		System.out.println(" Remaining balance is :" + withdraw1);                    
	                    	} else                                                                                 
	                    		System.out.println("the amount should not be more than available amount");         
	                                                          
	                                                                                                               
	                    break;                                                                                     
	                                                                                                               
	                  
	            case 5:
	                    System.out.println("Fund transfer");
	                    System.out.println("enter the account no of transferer");
	                    int accountnumber4=sc.nextInt();
	                    boolean valid3= service.validAccountNumber(accountnumber4);
	                    System.out.println(valid3);
	                    if (valid3) {  
	                    	System.out.println("enter the account no of receiver");
	                        int accountnumber5=sc.nextInt();
	                     
	                        boolean valid4= service.validAccountNumber(accountnumber5); 
	                        
	                        if (valid4) {
	                        	System.out.println("enter the amount to be withdraw");                                 
	                        	int amount = sc.nextInt(); 
	                        	  
	                        	double fund= service.fundTransfer(accountnumber4,accountnumber5,amount);
	                        	     if(fund>0){
	   							
	   								System.out.println("BALANCE IN OTHER ACCOUNT IS "+fund);
	   						          }else {
	   							          try
	   							          {
	   									throw new BankCustomerNotFound("SORRRY TRANSACTION FAILED!!!!");
	   									
	   						               	}
	   							        catch(BankCustomerNotFound e)
	   							          {
	   							      	System.out.println(e.getMessage());
	   							          }
	   							
	   						              }
	                                  }
	                        else
	   						{
	   							
	   							try
	   							{
	   									throw new BankCustomerNotFound("ENTER THE VALID account number to TRANSFER");
	   							}
	   							catch(BankCustomerNotFound e)
	   							{
	   								System.out.println(e.getMessage());
	   					
	                        }
	   						
	   						}
	                    }
	                  
	   						else
	   						{
	   							
	   							try
	   							{
	   									throw new BankCustomerNotFound("ENTER THE VALID DETAILS TO TRANSFER");
	   							}
	   							catch(BankCustomerNotFound e)
	   							{
	   								System.out.println(e.getMessage());
	   					
	                        }
	   						}
	                    
	                    
	        
	                   
	                    break;
	            case 6:
	                    System.out.println("Transaction");
	                    service.printTransaction();
	                    break;
	            case 7: System.exit(0);
	            default: 
	                    System.out.println("wrong choice");
	                    break;
	        }
	        
	            }
	        }
}