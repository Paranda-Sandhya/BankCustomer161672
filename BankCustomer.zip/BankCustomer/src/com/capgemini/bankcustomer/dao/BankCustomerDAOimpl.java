package com.capgemini.bankcustomer.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capg.bw.bean.Customer;
import com.capg.bw.exception.CustomerNotFound;
import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;
import com.capgemini.bankcustomer.utility.Util;

public class BankCustomerDAOimpl implements IBankCustomerDAO {
	private EntityManager em=null;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("BankCustomer");

	
 
  Scanner sc=new Scanner(System.in);
   
    @Override
    public void createAccount(BankCustomer b) throws BankCustomerNotFound {

		try{
			EntityManager em = factory.createEntityManager();
			em=Util.getEntityManager();
			em.getTransaction().begin();
			 // b.setAccountNumber(0);
			  em.persist(b);
			em.getTransaction().commit();			
	    	}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new BankCustomerNotFound(e.getMessage());
		}finally {
			
		}
		
	}

	@Override
	public BankCustomer showBalance(int accountNumber) throws BankCustomerNotFound {
		BankCustomer sb=null;
		try{
			
        	em=Util.getEntityManager();
       em.getTransaction().begin();
         sb=em.find(BankCustomer.class,accountNumber);
         System.out.println("balance is"+sb);
        	return sb;
        	}catch(PersistenceException e){
        		e.printStackTrace();
        		throw new BankCustomerNotFound(e.getMessage());
        	}finally
        	{
        		em.close();
        	}
        		
	}



    


    public double deposit(int accountNumber,double deposit) throws BankCustomerNotFound{
    	 {
    		 
    		 double dep=0;
    		 double temp=0;
    		// TODO Auto-generated method stub
    		 try{
    			 //EntityManager em = factory.createEntityManager();
    			em=Util.getEntityManager();
    		em.getTransaction().begin();
    			 BankCustomer b=em.find(BankCustomer.class,accountNumber);
    				 temp = b.getCurrentBalance();
    				temp = temp+deposit;
    				b.setCurrentBalance(temp);
    				em.merge(b);
    				em.getTransaction().commit();
    				dep=b.getCurrentBalance();
    				return dep;
    				
                  }catch(PersistenceException e){
         	       	e.printStackTrace();
         	    	throw new BankCustomerNotFound(e.getMessage());
             	
         		
         
                  }
    	 }
        
        
    }
    
    

    @Override
    public double withdraw(int accountNumber,double withdraw)throws BankCustomerNotFound {
    	double withdraw1=0;
    	try{
    		//EntityManager em = factory.createEntityManager();
			 em=Util.getEntityManager();
			 em.getTransaction().begin();
			 BankCustomer b=em.find(BankCustomer.class,accountNumber);
				double temp = b.getCurrentBalance();//storing actual balance in temporary variable
				temp = temp-withdraw;
				b.setCurrentBalance(temp);//set the amount which we had withdrawn in object b
			em.merge(b);
				em.getTransaction().commit();
				withdraw1=b.getCurrentBalance();
				return withdraw1;
				
             }catch(PersistenceException e){
    	       	e.printStackTrace();
    	    	throw new BankCustomerNotFound(e.getMessage());
             }	
    		
    }
public double fundTransfer(int senderAcc ,int receiverAcc, double fund)throws BankCustomerNotFound {
    	


	double amt2;
	try{
		
	    withdraw(senderAcc, fund);
	   amt2=deposit(receiverAcc,fund);
	    
	 if(amt2<0)
	 {
		 return 0;
		 
	 }
	
}catch(PersistenceException e){
	e.printStackTrace();
	throw new BankCustomerNotFound(e.getMessage());
}finally{
	//em.close();
}
return amt2;
}

	public void printTransaction() {
        // TODO Auto-generated method stub
        
    }

    

   public boolean validAccountNumber(int accountNumber4)throws BankCustomerNotFound {
      {
	 		boolean flag=false;
	       try {
	       	
	       	entityManager em =factory.createEntityManager();
	       	em=Util.getEntityManager();
	       	BankCustomer c=em.find(BankCustomer.class,accountNumber4);
	       	System.out.println(c);
	       	if(c.getAccountNumber()==accountNumber4)
	       	{
	       		flag=true;
	       	}
	       	 return flag;
	       	
	      } catch(PersistenceException e) {
	 			e.printStackTrace();
	 			throw new BankCustomerNotFound(e.getMessage());
	 		} finally {
	 			
	 		}
      return true;
  }
        
    

    public boolean validateAmount(double withdraw)throws BankCustomerNotFound {
		boolean flag=false;
		
//		for(Bean b:m.values())
//		{
//			System.out.println(b.getCurrentBalance());
//			if((b.getCurrentBalance()-withdraw)>500) 
//			{
//				
//				flag=true;
//			}
		
		
	//}
	
	return flag;
}
}