package com.capgemini.bankcustomer.dao;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;
import javax.transaction.Transaction;

import java.util.Iterator;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.dto.PrintTransaction;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;
import com.capgemini.bankcustomer.utility.Util;

public class BankCustomerDAOimpl implements IBankCustomerDAO {
	private EntityManager em=null;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("BankCustomer");

	
 
  Scanner sc=new Scanner(System.in);
   
    
   
    @Override
    public void createAccount(BankCustomer b) throws BankCustomerNotFound {

		try{
			EntityManager em = factory.createEntityManager();
			em=Util.getEntityManager();
			em.getTransaction().begin();
			 // b.setAccountNumber(0);
			  em.persist(b);
			em.getTransaction().commit();			
	    	}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new BankCustomerNotFound(e.getMessage());
		}finally {
			
		}
		
	}

	@Override
	public BankCustomer showBalance(int accountNumber) throws BankCustomerNotFound {
		BankCustomer sb=null;
		try{
			
        	em=Util.getEntityManager();
       em.getTransaction().begin();
         sb=em.find(BankCustomer.class,accountNumber);
         System.out.println("balance is"+sb);
        	return sb;
        	}catch(PersistenceException e){
        		e.printStackTrace();
        		throw new BankCustomerNotFound(e.getMessage());
        	}finally
        	{
        		em.close();
        	}
        		
	}



    


    public double deposit(int accountNumber,double deposit,PrintTransaction transaction) throws BankCustomerNotFound{
    	 {
    		 //PrintTransaction transaction=null;
    		 double dep=0;
    		 double temp=0;
    		// TODO Auto-generated method stub
    		 try{
    			 //EntityManager em = factory.createEntityManager();
    			em=Util.getEntityManager();
    		    em.getTransaction().begin();
    			 BankCustomer b=em.find(BankCustomer.class,accountNumber);
    			 if(deposit>0)
    			 {
    			 temp = b.getCurrentBalance();
    			temp = temp+deposit;
    			b.setCurrentBalance(temp);
    				//PrintTransaction transaction;
					transaction.setBalance(temp);
    				em.merge(b);
    				em.getTransaction().commit();
    				PrintTransaction transaction1 = addTransaction(transaction);
    				dep=b.getCurrentBalance();
    				return dep;
    			 }
    		 }
             
                	  catch(PersistenceException e){
                          
                	  System.out.println("Enter valid amount to be deposited");
                   
         	       	e.printStackTrace();
         	    	throw new BankCustomerNotFound(e.getMessage());
                  }
    		 
    	 return dep;
    }
    }             
 
   
    	
		
	

	@Override
    public double withdraw(int accountNumber,double withdraw, PrintTransaction transaction)throws BankCustomerNotFound {
    	double withdraw1=0;
    	try{
    		//EntityManager em = factory.createEntityManager();
			 em=Util.getEntityManager();
			 em.getTransaction().begin();
			 BankCustomer b=em.find(BankCustomer.class,accountNumber);
				double temp = b.getCurrentBalance();//storing actual balance in temporary variable
				temp = temp-withdraw;
				b.setCurrentBalance(temp);
				transaction.setBalance(temp);//set the amount which we had withdrawn in object b
			em.merge(b);
				em.getTransaction().commit();
				PrintTransaction transaction1 = addTransaction(transaction);
				withdraw1=b.getCurrentBalance();
				return withdraw1;
				
             }catch(PersistenceException e){
    	       	e.printStackTrace();
    	    	throw new BankCustomerNotFound(e.getMessage());
             }	
    		
    }
public PrintTransaction fundTransfer(int senderAcc ,int receiverAcc, double fund, PrintTransaction transaction)throws BankCustomerNotFound {
    	

/*
	double amt2;
	try{
		
	    withdraw(senderAcc, fund, transaction);
	   amt2=deposit(receiverAcc,fund, transaction);
	    
	 if(amt2<0)
	 {
		 return 0;
		 
	 }*/
	
	BankCustomer account, account1 = null;
	PrintTransaction transaction1;
	try {
		em = Util.getEntityManager();
		em.getTransaction().begin();
		account = em.find(BankCustomer.class, senderAcc);
		if (account.getCurrentBalance() - fund > 5000) {
			Double newBalance = account.getCurrentBalance() - fund;
			account.setCurrentBalance(newBalance);
			transaction.setBalance(newBalance);
			em.merge(account);
           account1 =em.find(BankCustomer.class, receiverAcc);
			Double newBalance1 = account1.getCurrentBalance() + fund;
			account1.setCurrentBalance(newBalance1);

		
			em.merge(account1);
			em.getTransaction().commit();

			transaction1 = addTransaction(transaction);

			return transaction1;
		} else {
			PrintTransaction transaction2 = null;
			return transaction2;
		}
	} catch (PersistenceException e) {
		// TODO: Log to file
		throw new BankCustomerNotFound(e.getMessage());
	} finally {

	}

}


@Override
public List<PrintTransaction> printTransaction(long accountNo) throws BankCustomerNotFound{
	// TODO Auto-generated method stub
	EntityManager entityManager = Util.getEntityManager();
	String jql = "select e from Transaction a where a.accountNo=:saccountNo";
	TypedQuery<PrintTransaction> typedQuery = entityManager.createQuery(jql, PrintTransaction.class);
	typedQuery.setParameter("saccountNo", accountNo);
	List<PrintTransaction> transactionList = typedQuery.getResultList();
	return transactionList;
}

   public boolean validAccountNumber(int accountNumber4)throws BankCustomerNotFound {
      /*boolean flag=false;
        for(Bean b:m.values())
        {
           if( b.getAccountNumber()==accountNumber4 && b.getPin()==pin4)
            {
            
                flag= true;
                
            
            }
    
       }*/
      return true;
  }
        
    

    public boolean validateAmount(double withdraw)throws BankCustomerNotFound {
		boolean flag=false;
		
//		for(Bean b:m.values())
//		{
//			System.out.println(b.getCurrentBalance());
//			if((b.getCurrentBalance()-withdraw)>500) 
//			{
//				
//				flag=true;
//			}
		
		
	//}
	
	return flag;
}

	@Override
	public PrintTransaction addTransaction(PrintTransaction transaction)
			throws BankCustomerNotFound {
		// TODO Auto-generated method stub
		PrintTransaction transaction1 = null;
		try {
			em = Util.getEntityManager();
			em.getTransaction().begin();
			em.persist(transaction);
			em.getTransaction().commit();
			transaction1 = transaction;
		} catch (PersistenceException e) {
			e.printStackTrace();
			// TODO: Log to file
			throw new BankCustomerNotFound(e.getMessage());
		} finally {

		}
		return transaction1;	}
}