package com.capgemini.bankcustomer.dao;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.PersistenceException;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;
import com.capgemini.bankcustomer.utility.Util;






public class BankCustomerDAOimpl implements IBankCustomerDAO {
	private EntityManager entityManager;
	EntityManagerFactory factory = Persistence.createEntityManagerFactory("BankCustomer");
	EntityManager em = factory.createEntityManager();
   
    
 
  Scanner sc=new Scanner(System.in);
   
    
   
    @Override
    public void createAccount(BankCustomer b) throws BankCustomerNotFound {

		try{
			
			entityManager=Util.getEntityManager();
			 entityManager.getTransaction().begin();
			  b.setAccountNumber(0);
			  entityManager.persist(b);
			//transaction.commit
			  entityManager.getTransaction().commit();			
	    	}catch(PersistenceException e) {
			e.printStackTrace();
			//TODO: Log to file
			throw new BankCustomerNotFound(e.getMessage());
		}finally {
			entityManager.close();
		}
		
	}

	@Override
	public double showBalance(int accountNumber) throws BankCustomerNotFound {
		
		try{
        	entityManager=Util.getEntityManager();
        	BankCustomer b=entityManager.find(BankCustomer.class,accountNumber);
        	return b.getCurrentBalance();
        	}catch(PersistenceException e){
        		e.printStackTrace();
        		throw new BankCustomerNotFound(e.getMessage());
        	}finally
        	{
        		entityManager.close();
        	}
        		
	}



    


    @Override
    public double deposit(double deposit,int accountNumber) throws BankCustomerNotFound{
    	 {
    		 
    		 double deposit1=0;
    		// TODO Auto-generated method stub
    		 try{
    			 entityManager=Util.getEntityManager();
    			 entityManager.getTransaction().begin();
    			 BankCustomer b=entityManager.find(BankCustomer.class,accountNumber);
    				double temp = b.getCurrentBalance();
    				temp = temp+deposit;
    				b.setCurrentBalance(temp);
    				entityManager.merge(b);
    				entityManager.getTransaction().commit();
    				deposit1=b.getCurrentBalance();
    				return deposit1;
    				
                  }catch(PersistenceException e){
         	       	e.printStackTrace();
         	    	throw new BankCustomerNotFound(e.getMessage());
             	}finally
         	{
         		entityManager.close();
         	}
         		
         	}
    		
        
        
    }
    
    

    @Override
    public double withdraw(int accountNumber,double withdraw)throws BankCustomerNotFound {
    	double withdraw1=0;
    	try{
			 entityManager=Util.getEntityManager();
			 entityManager.getTransaction().begin();
			 BankCustomer b=entityManager.find(BankCustomer.class,accountNumber);
				double temp = b.getCurrentBalance();//storing actual balance in temporary variable
				temp = temp-withdraw;
				b.setCurrentBalance(temp);//set the amount which we had withdrawn in object b
				entityManager.merge(b);
				entityManager.getTransaction().commit();
				withdraw1=b.getCurrentBalance();
				return withdraw1;
				
             }catch(PersistenceException e){
    	       	e.printStackTrace();
    	    	throw new BankCustomerNotFound(e.getMessage());
        	}finally
    	{
    		entityManager.close();
    	}
    		
    }
public double fundTransfer(int accountNumber4,int accountNumber5,int amount)throws BankCustomerNotFound {
    	
    	
		withdraw(accountNumber4,amount);
		
		double d=deposit(amount,accountNumber5);
		if(d>0)
		{
			return d;
		}else
		return -1;
		
		
		}
		
    

    
    public void printTransaction() {
        // TODO Auto-generated method stub
        
    }

    

   public boolean validAccountNumber(int accountNumber4)throws BankCustomerNotFound {
      /*boolean flag=false;
        for(Bean b:m.values())
        {
           if( b.getAccountNumber()==accountNumber4 && b.getPin()==pin4)
            {
            
                flag= true;
                
            
            }
    
       }*/
      return true;
  }
        
    

    public boolean validateAmount(double withdraw)throws BankCustomerNotFound {
		boolean flag=false;
		
//		for(Bean b:m.values())
//		{
//			System.out.println(b.getCurrentBalance());
//			if((b.getCurrentBalance()-withdraw)>500) 
//			{
//				
//				flag=true;
//			}
		
		
	//}
	
	return flag;
}









	




}