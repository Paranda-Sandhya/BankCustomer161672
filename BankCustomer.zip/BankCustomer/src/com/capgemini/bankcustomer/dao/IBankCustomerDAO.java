package com.capgemini.bankcustomer.dao;



import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;



public interface IBankCustomerDAO {
	
	
	public void createAccount(BankCustomer b) throws BankCustomerNotFound;
	public BankCustomer showBalance(int accountNumber)throws BankCustomerNotFound; 


	public double deposit(int accountNumber,double deposit) throws BankCustomerNotFound;

	public double withdraw(int accountNumber, double withdraw) throws BankCustomerNotFound;

	
	public double fundTransfer(int senderAcc ,int receiverAcc, double fund)
			throws BankCustomerNotFound;
	public void printTransaction()throws BankCustomerNotFound;
	// public boolean valid(long accountNumber) throws BankCustomerNotFound;



	public boolean validAccountNumber(int accountNumber5) throws BankCustomerNotFound;;

	public boolean validateAmount(double withdraw)throws BankCustomerNotFound;

	
}