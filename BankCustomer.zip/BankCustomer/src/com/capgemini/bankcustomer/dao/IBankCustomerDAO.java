package com.capgemini.bankcustomer.dao;

import org.springframework.context.annotation.Bean;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;



public interface IBankCustomerDAO {
	
	
	public void createAccount(BankCustomer b) throws BankCustomerNotFound;
	public double showBalance(int accountNumber)throws BankCustomerNotFound; 


	public double deposit(double deposit,int accountNumber) throws BankCustomerNotFound;

	public double withdraw(int accountNumber, double withdraw) throws BankCustomerNotFound;

	
	public double fundTransfer(int accountNumber4, int accountNumber5, int amount)
			throws BankCustomerNotFound;
	public void printTransaction()throws BankCustomerNotFound;


	public boolean validAccountNumber(int accountNumber5) throws BankCustomerNotFound;;

	public boolean validateAmount(double withdraw)throws BankCustomerNotFound;

	
}