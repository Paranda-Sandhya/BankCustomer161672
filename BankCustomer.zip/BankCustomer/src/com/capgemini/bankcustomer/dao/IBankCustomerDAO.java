package com.capgemini.bankcustomer.dao;



import java.util.List;

import javax.transaction.Transaction;

import com.capgemini.bankcustomer.dto.BankCustomer;
import com.capgemini.bankcustomer.dto.PrintTransaction;
import com.capgemini.bankcustomer.exception.BankCustomerNotFound;



public interface IBankCustomerDAO {
	
	
	public void createAccount(BankCustomer b) throws BankCustomerNotFound;
	public BankCustomer showBalance(int accountNumber)throws BankCustomerNotFound; 


	public double deposit(int accountNumber,double deposit,PrintTransaction transaction) throws BankCustomerNotFound;

	public double withdraw(int accountNumber, double withdraw, PrintTransaction transaction) throws BankCustomerNotFound;

	
	public PrintTransaction fundTransfer(int senderAcc ,int receiverAcc, double fund,PrintTransaction transaction)
			throws BankCustomerNotFound;
	public List<PrintTransaction> printTransaction(long accountNo)throws BankCustomerNotFound;
	public PrintTransaction addTransaction(PrintTransaction transaction) throws BankCustomerNotFound;

	public boolean validAccountNumber(int accountNumber5) throws BankCustomerNotFound;;

	
	
}